# euri-test-api

Fake Online REST API for Testing and Prototyping

Copyright (c) 2018 Euricom nv. Licensed under the [MIT license](https://opensource.org/licenses/MIT).
